package views;

import logic.GameController;

public class TicTacToeFrame extends BaseFrame {
    private GameController controller;
    
    public TicTacToeFrame() {
        initComponents();
        controller = new GameController(this);
        setSize(620, 640);
        setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel_GridHolder = new javax.swing.JPanel();
        panel_1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        panel_2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        panel_3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        panel_4 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        panel_5 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        panel_6 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        panel_7 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        panel_8 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        panel_9 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jPanel_Information = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        status_lb = new javax.swing.JLabel();
        player_two_score_lb = new javax.swing.JLabel();
        player_one_score_lb = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tic Tac Toe");

        jPanel1.setBackground(new java.awt.Color(33, 40, 69));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 640));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel_GridHolder.setBackground(new java.awt.Color(0, 0, 204));
        jPanel_GridHolder.setLayout(new java.awt.GridLayout(3, 3, 2, 2));

        panel_1.setBackground(new java.awt.Color(33, 40, 69));
        panel_1.setForeground(new java.awt.Color(33, 40, 69));
        panel_1.setLayout(new java.awt.BorderLayout());

        jButton1.setBackground(new java.awt.Color(33, 40, 69));
        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 204, 0));
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        panel_1.add(jButton1, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_1);

        panel_2.setBackground(new java.awt.Color(33, 40, 69));
        panel_2.setForeground(new java.awt.Color(33, 40, 69));
        panel_2.setLayout(new java.awt.BorderLayout());

        jButton2.setBackground(new java.awt.Color(33, 40, 69));
        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 204, 0));
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        panel_2.add(jButton2, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_2);

        panel_3.setBackground(new java.awt.Color(33, 40, 69));
        panel_3.setForeground(new java.awt.Color(33, 40, 69));
        panel_3.setLayout(new java.awt.BorderLayout());

        jButton3.setBackground(new java.awt.Color(33, 40, 69));
        jButton3.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 204, 0));
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        panel_3.add(jButton3, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_3);

        panel_4.setBackground(new java.awt.Color(33, 40, 69));
        panel_4.setForeground(new java.awt.Color(33, 40, 69));
        panel_4.setLayout(new java.awt.BorderLayout());

        jButton4.setBackground(new java.awt.Color(33, 40, 69));
        jButton4.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 204, 0));
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        panel_4.add(jButton4, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_4);

        panel_5.setBackground(new java.awt.Color(33, 40, 69));
        panel_5.setForeground(new java.awt.Color(33, 40, 69));
        panel_5.setLayout(new java.awt.BorderLayout());

        jButton5.setBackground(new java.awt.Color(33, 40, 69));
        jButton5.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 204, 0));
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        panel_5.add(jButton5, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_5);

        panel_6.setBackground(new java.awt.Color(33, 40, 69));
        panel_6.setForeground(new java.awt.Color(33, 40, 69));
        panel_6.setLayout(new java.awt.BorderLayout());

        jButton6.setBackground(new java.awt.Color(33, 40, 69));
        jButton6.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 204, 0));
        jButton6.setBorder(null);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        panel_6.add(jButton6, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_6);

        panel_7.setBackground(new java.awt.Color(33, 40, 69));
        panel_7.setForeground(new java.awt.Color(33, 40, 69));
        panel_7.setLayout(new java.awt.BorderLayout());

        jButton7.setBackground(new java.awt.Color(33, 40, 69));
        jButton7.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 204, 0));
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        panel_7.add(jButton7, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_7);

        panel_8.setBackground(new java.awt.Color(33, 40, 69));
        panel_8.setForeground(new java.awt.Color(33, 40, 69));
        panel_8.setLayout(new java.awt.BorderLayout());

        jButton8.setBackground(new java.awt.Color(33, 40, 69));
        jButton8.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 204, 0));
        jButton8.setBorder(null);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        panel_8.add(jButton8, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_8);

        panel_9.setBackground(new java.awt.Color(33, 40, 69));
        panel_9.setForeground(new java.awt.Color(33, 40, 69));
        panel_9.setLayout(new java.awt.BorderLayout());

        jButton9.setBackground(new java.awt.Color(33, 40, 69));
        jButton9.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 80)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 204, 0));
        jButton9.setBorder(null);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        panel_9.add(jButton9, java.awt.BorderLayout.CENTER);

        jPanel_GridHolder.add(panel_9);

        jPanel1.add(jPanel_GridHolder, java.awt.BorderLayout.CENTER);

        jPanel_Information.setBackground(new java.awt.Color(33, 40, 69));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText(":   Player Two");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 204, 0));
        jLabel3.setText("Player One   :");

        status_lb.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        status_lb.setForeground(new java.awt.Color(255, 204, 0));
        status_lb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        status_lb.setText("Player One Turn");

        player_two_score_lb.setBackground(new java.awt.Color(255, 255, 255));
        player_two_score_lb.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        player_two_score_lb.setForeground(new java.awt.Color(255, 255, 255));
        player_two_score_lb.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        player_two_score_lb.setText("0");

        player_one_score_lb.setBackground(new java.awt.Color(255, 255, 255));
        player_one_score_lb.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        player_one_score_lb.setForeground(new java.awt.Color(255, 255, 255));
        player_one_score_lb.setText("0");

        javax.swing.GroupLayout jPanel_InformationLayout = new javax.swing.GroupLayout(jPanel_Information);
        jPanel_Information.setLayout(jPanel_InformationLayout);
        jPanel_InformationLayout.setHorizontalGroup(
            jPanel_InformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_InformationLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(player_one_score_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(status_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(player_two_score_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel_InformationLayout.setVerticalGroup(
            jPanel_InformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_InformationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel_InformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel_InformationLayout.createSequentialGroup()
                        .addGroup(jPanel_InformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(player_one_score_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel_InformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(player_two_score_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel_InformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel_InformationLayout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(status_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel1.add(jPanel_Information, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void reset(){
        jButton1.setText("");
        jButton2.setText("");
        jButton3.setText("");
        jButton4.setText("");
        jButton5.setText("");
        jButton6.setText("");
        jButton7.setText("");
        jButton8.setText("");
        jButton9.setText("");
        
        status_lb.setText("Player One Turn");
    }
    
    private void setScore() {
        int player = controller.getPlayer();
        
        if (!controller.isTie()){
            if (player == 1){
                String str_score = player_two_score_lb.getText();
                int score = Integer.parseInt(str_score) + 1;

                player_two_score_lb.setText(Integer.toString(score++));
            }else{
                String str_score = player_one_score_lb.getText();
                int score = Integer.parseInt(str_score) + 1;

                player_one_score_lb.setText(Integer.toString(score++));
            }            
        }
    }
    
    private void setStatusLabel(){
        int player = controller.getPlayer();

        if (player == 1){
            status_lb.setText("Player One Turn");
        }else{
            status_lb.setText("Player Two Turn");
        }
    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jButton3.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(2, jButton3.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jButton4.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(3, jButton4.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jButton1.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(0, jButton1.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jButton2.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(1, jButton2.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jButton5.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(4, jButton5.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        jButton6.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(5, jButton6.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        jButton7.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(6, jButton7.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        jButton8.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(7, jButton8.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        jButton9.setText(controller.turnOutput());
        setStatusLabel();
        if (controller.checkWin(8, jButton9.getText())){
            setScore();
            controller.resetGame();
            reset();
        }
    }//GEN-LAST:event_jButton9ActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel_GridHolder;
    private javax.swing.JPanel jPanel_Information;
    private javax.swing.JPanel panel_1;
    private javax.swing.JPanel panel_2;
    private javax.swing.JPanel panel_3;
    private javax.swing.JPanel panel_4;
    private javax.swing.JPanel panel_5;
    private javax.swing.JPanel panel_6;
    private javax.swing.JPanel panel_7;
    private javax.swing.JPanel panel_8;
    private javax.swing.JPanel panel_9;
    private javax.swing.JLabel player_one_score_lb;
    private javax.swing.JLabel player_two_score_lb;
    private javax.swing.JLabel status_lb;
    // End of variables declaration//GEN-END:variables
}
