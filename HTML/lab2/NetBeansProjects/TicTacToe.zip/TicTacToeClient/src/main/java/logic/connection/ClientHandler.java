package logic.connection;

import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClientHandler {
    public static final String ADDRESS = "localhost";
    public int port;
    private Socket client;
    
    private ClientHandler() {
    }
    
    public static ClientHandler getInstance() {
        return ClientHandlerHolder.INSTANCE;
    }
    
    private static class ClientHandlerHolder {

        private static final ClientHandler INSTANCE = new ClientHandler();
    }
    
    public void openConnection(int port){
        this.port = port;
        try {
            client = new Socket(ADDRESS, port);
        } catch (IOException e) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
