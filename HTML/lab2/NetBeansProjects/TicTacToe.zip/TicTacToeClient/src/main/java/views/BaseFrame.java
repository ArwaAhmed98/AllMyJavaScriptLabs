package views;

public class BaseFrame extends javax.swing.JFrame{
    private String port;

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }
    
    public void redirect(BaseFrame destination){
        destination.setVisible(true);
    }
}
