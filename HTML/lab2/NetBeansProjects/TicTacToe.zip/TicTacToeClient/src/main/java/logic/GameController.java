package logic;

import javax.swing.JOptionPane;
import views.TicTacToeFrame;

public class GameController {
    private boolean tie_status = false;     //status tie or not
    private int move = 0;
    private int player = 1;         //1 for player 1, 2 for player 2
    private String[][] board;
    private String turnOutput = "O";
    private TicTacToeFrame ticTacToeFrame;

    public GameController(TicTacToeFrame ticTacToeFrame) {
        this.board = new String[][]{
                                    {"", "", ""}, 
                                    {"", "", ""}, 
                                    {"", "", ""}
                                  };
        this.ticTacToeFrame = ticTacToeFrame;
    }
    
    public String turnOutput(){
        if (turnOutput.equalsIgnoreCase("X")){
            turnOutput = "O";
            player = 1;
        }else{
            turnOutput = "X";
            player = 2;
        }
        
        return turnOutput;
    }
    
    public boolean rowCheck(){
        for (int i = 0; i < 3; i++)
            if (board[i][0] == board[i][1] &&
                board[i][1] == board[i][2] &&
                board[i][0] != "")
                return true;            
        
        return false;
    }
    
    public boolean columnCheck(){
        for (int i = 0; i < 3; i++)
            if (board[0][i] == board[1][i] &&
                board[1][i] == board[2][i] &&
                board[0][i] != "")
                return true;            
        
        return false;
    }
    
    public boolean diagonalCheck(){
        if (board[0][0] == board[1][1] && 
            board[1][1] == board[2][2] &&  
            board[0][0] != "") 
            return true; 
          
        if (board[0][2] == board[1][1] && 
            board[1][1] == board[2][0] && 
            board[0][2] != "") 
            return true; 
  
        return false;
    }
    
    public boolean gameOver(){
        return (rowCheck() || columnCheck() || diagonalCheck());
    }
    
    public boolean checkWin(int tabIndex, String text){
        int x = tabIndex / 3;
        int y = tabIndex % 3; 
        board[x][y] = text;
        move++;
        
        if (gameOver() && move != 9){
            message(player);
            
            return true;
        }
        
        if (move == 9){
            message(0);
            
            return true;
        }
        
        return false;
    }
        
    public void message(int winner){
        //Player 1 and 2 switched
        switch (winner) {   
            case 1:
                JOptionPane.showMessageDialog(ticTacToeFrame,
                        "Player Two Win",
                        "Winner",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            case 2:
                JOptionPane.showMessageDialog(ticTacToeFrame,
                        "Player One Win",
                        "Winner",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            default:
                tie_status = true;
                JOptionPane.showMessageDialog(ticTacToeFrame,
                        "It's a draw",
                        "Draw",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
        }
    }
    
    public void resetGame(){
        board = new String[][]{
                               {"", "", ""}, 
                               {"", "", ""}, 
                               {"", "", ""}
                             };
        turnOutput = "O";
        move = 0;
        player = 1; 
        tie_status = false;
    }

    public int getPlayer() {
        return player;
    }

    public boolean isTie() {
        return tie_status;
    }
}
