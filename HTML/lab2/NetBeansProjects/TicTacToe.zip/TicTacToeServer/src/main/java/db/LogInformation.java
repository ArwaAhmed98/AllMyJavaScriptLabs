package db;

public class LogInformation {
    String information = "Server Tic Tac Toe Information Message";
    
    private LogInformation() {
    }
    
    public static LogInformation getInstance() {
        return LogInformationHolder.INSTANCE;
    }
    
    private static class LogInformationHolder {

        private static final LogInformation INSTANCE = new LogInformation();
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String new_information) {
        this.information = this.information + "\n" + new_information;
    } 
}
