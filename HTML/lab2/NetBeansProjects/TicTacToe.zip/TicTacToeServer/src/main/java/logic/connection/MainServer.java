package logic.connection;

import db.LogInformation;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import views.ServerFrame;

public class MainServer extends Thread{
    private static final int PORT = 1234;
    private ServerSocket serverSocket;
    private Socket server;
    private String information = "";
    
    private MainServer() {
    }
        
    public static MainServer getInstance() {
        return MainServerHolder.INSTANCE;
    }
    
    private static class MainServerHolder {
        private static final MainServer INSTANCE = new MainServer();
    }
    
    public void openConnection(){
        try {
            information = "Server Strated";
            writeInformation();
            serverSocket = new ServerSocket(PORT);
            information = "Waiting for connection...";
            writeInformation();
            this.start();
        } catch (IOException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void run() {
        while (true) {            
            try {
                server = serverSocket.accept();
                information = "Connected to " + server.getRemoteSocketAddress();
                writeInformation();
            } catch (IOException e) {
                e.getStackTrace();
            }
        }
    }
    
    private void writeInformation(){
        LogInformation.getInstance().setInformation(information);
    }
}
