# Tic-Tac-Toe-Server-based-program
Tic Tac Toe program is a console based application using socket programming in java

Run the Server.java file first from the Games Folder

Then start ClientApp.java file which will connect to the server program.
Start another ClientApp.java as a second player.

Both client app can play against each other using the server.


For code explanation refer: https://youtu.be/krztnJyXQcc
